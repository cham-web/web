<template>
  <div class="map">
    <slot name="marker"></slot>
    <div id="myMap" class="map-box"></div>
    <div class="tools">
      <div @click="mapClick" v-if="isOpenMarker">
        <img src="./assets/marker.png" alt="" />
      </div>
      <div @click="createFace" v-if="isPolygon">
        <img src="./assets/mian.png" alt="" srcset="" />
      </div>
    </div>
  </div>
</template>

<script>
import "./leaflet";
// import L from "leaflet";
import Provider from "./chinatmsproviders";
// require("leaflet/dist/leaflet.css");
// require("leaflet.markercluster/dist/MarkerCluster.css");
// require("leaflet.markercluster/dist/MarkerCluster.Default.css");
// import "leaflet.markercluster";

import("./leaflet.css");
import("./leaflet.markercluster/MarkerCluster.css");
import("./leaflet.markercluster/MarkerCluster.Default.css");
import "./leaflet.markercluster/leaflet.markercluster";
import "./turf.min.js";
export default {
  props: {
    isOpenMarker: {
      // 是否开启marker点标记
      type: Boolean,
      default: true,
    },
    isClearMarker: {
      // 是否清理marker点标记
      type: Boolean,
      default: true,
    },
    isPolygon: {
      // 是否开启画面
      type: Boolean,
      default: false,
    },
    providers: {
      // 地图供应商
      type: String,
      default: "TianDiTu",
    },
  },
  data() {
    return {
      mapKey: "28d8ba51e8730311b3da860bce894af5", // 你的key
      serverKey: "74f1643d349fb2c4d6e3fb77b8d90780", // 服务key
      map: "",
      markersArr: [], // marker标记数组
      visible: false,
      markers: "",

      points: [], // 画的过程中的点
      lines: {}, // 画的过程中生成的多边形
      tempLines: {}, // 鼠标移动中生成的多边形（实际是一条线段）
      polygonList: {}, // 双击结束生成多边形
      facelines: [], // 存储画的多边形
      facetempLines: [], // 存储移动的多边形
      facepolygonList: [], // 存储结束生成的多边形
    };
  },
  mounted() {
    Provider(L); // 挂载插件
  },
  methods: {
    clearMap() {
      this.map.eachLayer((item) => {
        if (
          item._markerCluster != null ||
          item instanceof L.Marker ||
          item instanceof L.Polygon
        ) {
          item.remove();
        }
      });
    },
    removePolygon() {
      this.points.forEach((item) => {
        this.map.removeLayer(item);
      });
      this.facelines.forEach((item) => {
        this.map.removeLayer(item);
      });
      this.facetempLines.forEach((item) => {
        this.map.removeLayer(item);
      });
      // this.facepolygonList.forEach((item) => {
      //   this.map.removeLayer(item);
      // });
      this.points = [];
      this.facelines = [];
      this.facetempLines = [];
      // this.facepolygonList = [];
    },
    createFace() {
      this.map.off("click");
      this.removePolygon();
      this.$message.success("请在地图绘制多边形,双击结束自动生成");
      this.lines = L.polyline([], {
        color: "#fc6a00",
        fillColor: "#fc6a00",
        fillOpacity: 0.2,
      });
      this.tempLines = L.polyline([], {
        color: "#fc6a00",
        fillColor: "#fc6a00",
        fillOpacity: 0.2,
      });
      this.map.addLayer(this.lines);
      this.map.addLayer(this.tempLines);

      this.map.on("click", (e) => {
        this.points.push([e.latlng.lat, e.latlng.lng]);
        this.lines.addLatLng(e.latlng);
        this.map.addLayer(this.lines);
        this.facelines.push(this.lines);
      });
      this.map.on("mousemove", (e) => {
        if (this.points.length > 0) {
          this.tempLines.setLatLngs([
            this.points[this.points.length - 1],
            [e.latlng.lat, e.latlng.lng],
          ]);
          this.map.addLayer(this.tempLines);
          this.facetempLines.push(this.tempLines);
        }
      });
      this.map.on("dblclick", (e) => {
        console.log(this.points);
        this.polygonList = L.polygon([this.points], {
          color: "#fc6a00",
          fillColor: "#fc6a00",
          fillOpacity: 0.2,
          id: this.videoSearchID,
        }).addTo(this.map);
        this.map.addLayer(this.polygonList);
        // 默认平方米
        this.polygonList.options.m2 = turf.area(
          turf.polygon(this.polygonList.toGeoJSON().geometry.coordinates)
        );
        this.facepolygonList.push(this.polygonList);
        this.points = [];
        this.lines.setLatLngs([]);
        console.log(this.polygonList);

        this.emit("polygon", this.facepolygonList);

        this.map.off("click");
        this.map.off("mousemove");
        this.map.off("dblclick");
      });
    },
    // 逆地址解析，如何是其他地图替换其他地图接口
    getAddressInfo(params, url = "http://api.tianditu.gov.cn/geocoder") {
      return new Promise((resolve, reject) => {
        if (params) {
          let paramsArray = [];
          //拼接参数
          Object.keys(params).forEach((key) =>
            paramsArray.push(key + "=" + params[key])
          );
          if (url.search(/\?/) === -1) {
            url += "?" + paramsArray.join("&");
          } else {
            url += "&" + paramsArray.join("&");
          }
        }
        fetch(url, {
          method: "GET",
        })
          .then((response) => response.json())
          .then((res) => {
            if (res.status != 0) {
              this.$message.error(res.msg);
              reject(res);
            }
            resolve(res.result);
          });
      });
    },
    // 逆地址解析，只传经纬度
    async geocorder(lng, lat) {
      const res = await this.getAddressInfo({
        postStr: JSON.stringify({
          lon: lng,
          lat: lat,
          ver: 1,
        }),
        type: "geocode",
        tk: this.mapKey,
      });
      return res;
    },
    mapClick() {
      this.map.on("click", async (res) => {
        if (this.isClearMarker && this.markersArr.length) {
          this.map.eachLayer((item) => {
            if (item._markerCluster != null || item instanceof L.Marker) {
              item.remove();
              this.markersArr = [];
            }
          });
          // this.markersArr.map((data,index) => {
          //   this.map.removeLayer(data)
          //   this.markersArr.splice(index, 1)
          // })
        }
        const addressInfo = await this.getAddressInfo({
          postStr: JSON.stringify({
            lon: res.latlng.lng,
            lat: res.latlng.lat,
            ver: 1,
          }),
          type: "geocode",
          tk: this.mapKey,
        });

        const markerUrl = L.icon({
          iconUrl: require("./assets/marker.png"), // 使用require加载标记图
          iconSize: [28, 35],
          iconAnchor: [14, 35],
          popupAnchor: [0, -35 / 2],
        });
        const marker = L.marker(res.latlng, {
          icon: markerUrl,
          title: addressInfo.formatted_address,
        })
          .addTo(this.map)
          .bindPopup(addressInfo.formatted_address, {
            closeButton: false,
          })
          .openPopup();
        this.markersArr.push(marker);
        console.log(this.markersArr, "204>>>>>>>>>");
        this.$forceUpdate();
        this.emit("marker", this.markersArr);
        this.map.off("click");
      });
    },
    emit(type, params) {
      console.log(type, params);
      this.$emit("change", {
        type,
        params,
      });
    },
    /* 
      点聚合方法
      @param markerArr 格式 [{latlng: {lat: ,lng: }, title: , icon: }]
    */
    markerClusFun(markerArr) {
      this.map.eachLayer((item) => {
        if (item._markerCluster != null || item instanceof L.Marker) {
          item.remove();
          this.markersArr = [];
        }
      });
      const markers = L.markerClusterGroup();
      if (markerArr.length) {
        markerArr.map((res) => {
          const markerUrl = L.icon({
            iconUrl: res.icon ? res.icon : require("./assets/marker.png"), // 使用require加载标记图
            iconSize: [28, 35],
            iconAnchor: [14, 35],
            popupAnchor: [0, -35 / 2],
          });
          const marker = L.marker(res.latlng, {
            ...res,
            icon: markerUrl,
          }).bindPopup(res.title, {
            closeButton: false,
          });
          this.markersArr.push(marker);
          markers.addLayer(marker);
        });
        console.log(this.markersArr, "265>>>>>>>.");
        this.map.setView(this.markersArr[0].getLatLng());
        console.log(markers, "242>>>>>>>>");
        this.map.addLayer(markers);
        this.emit("marker", this.markersArr);
      }
    },
    getMap(lng = 114.057939, lat = 22.543527) {
      var _this = this;
      function mapLoad(value) {
        return L.tileLayer.chinaProvider(_this.providers + `.${value}`, {
          minZoom: 3,
          key: _this.mapKey,
        });
      }
      // 定义地图图层，官方api有
      var norMap = mapLoad("Normal.Map"),
        norAnnotion = mapLoad("Normal.Annotion"),
        sateMap = mapLoad("Satellite.Map"),
        sateAnnotion = mapLoad("Satellite.Annotion");
      var normalMap = L.layerGroup([norMap, norAnnotion]), // 矢量
        satelliteMap = L.layerGroup([sateMap, sateAnnotion]); // 卫星
      // 名字要和data中的mapSelectList中value值对应
      var baseLayers = {
        Normal: normalMap,
        Satellite: satelliteMap,
      };
      let myCenter = new L.LatLng(lat, lng);
      let map = (this.map = L.map("myMap", {
        center: myCenter,
        zoom: 12,
        zoomControl: false,
        layers: [satelliteMap], //默认图层展示
      }));

      // L.tileLayer
      //   .chinaProvider(this.providers+".Satellite.Map", {
      //     minZoom: 3,
      //     key: this.mapKey
      //   })
      //   .addTo(map)
      // L.tileLayer
      //   .chinaProvider(this.providers+".Satellite.Annotion", {
      //     minZoom: 3,
      //     key: this.mapKey
      //   })
      //   .addTo(map)
      L.control
        .zoom({
          zoomInText: '<span aria-hidden="true">+</span>',
          zoomOutText: '<span aria-hidden="true">&#x2212;</span>',
          position: "bottomright",
        })
        .addTo(map);
      // 加载切换地图的功能（出现在页面右上角，可通过css隐藏）
      L.control
        .layers(baseLayers, null, {
          position: "bottomright",
        })
        .addTo(map);
    },
  },
};
</script>
<style scoped>
.map-box {
  width: 100%;
  height: 100%;
}
.map {
  position: relative;
  width: 100%;
  height: 100%;
}
.tools {
  position: absolute;
  top: 50%;
  right: 10px;
  z-index: 99999;
  transform: translateY(-50%);
}
.tools div {
  background-color: white;
  margin-bottom: 10px;
  padding: 10px;
  box-sizing: border-box;
  border-radius: 50%;
  cursor: pointer;
}
.tools div img {
  width: 30px;
  height: 30px;
  display: block;
}
</style>
