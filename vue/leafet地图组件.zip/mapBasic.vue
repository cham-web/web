<template>
  <div class="home">
    <cy-map ref="map" :isPolygon="true" @change="handleChange"></cy-map>
  </div>
</template>

<script>
import '@/components/CyMap/leaflet'
import CyMap from '@/components/CyMap'
export default {
  components: {CyMap},
  created() {
    this.$nextTick(() => {
      this.$refs.map.getMap()
      this.$refs.map.markerClusFun([
          {
              "latlng": {
                  "lat": 34.66258150231496,
                  "lng": 113.17016601562501
              },
              "title": "河南省郑州市巩义市新中镇冷沟"
          },
          {
              "latlng": {
                  "lat": 34.46354183877718,
                  "lng": 113.48327636718751
              },
              "title": "河南省郑州市新密市来集镇李家沟东北约261米"
          },
          {
              "latlng": {
                  "lat": 34.68065238482746,
                  "lng": 113.67553710937501
              },
              "title": "河南省郑州市管城回族区十八里河镇公厕西北约118米"
          },
          {
              "latlng": {
                  "lat": 34.264026473152896,
                  "lng": 113.79089355468751
              },
              "title": "河南省许昌市长葛市佛耳湖镇丑楼-x001公路西南约538米"
          },
          {
              "latlng": {
                  "lat": 34.0731374116421,
                  "lng": 112.90924072265625
              },
              "title": "河南省平顶山市汝州市小屯镇小屯出口东北约432米"
          }
      ])
    })
  }, 
  methods: {
    handleChange(e) {
      console.log(e);
      if(e.type === 'marker') {
        e.params.map(item => {
          item.on('click', res => {
            res.target.setIcon(L.icon({
              iconUrl: require('../assets/icon.png')
            }))
          })
        })
      }
    }
  }
}
</script>

<style scoped>
.home{
  width: 100vh;
  height: 100vh;
}
</style>
